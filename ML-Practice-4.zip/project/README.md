# Лабораторна робота №4
Мулявко Софія Марківна, Феі-46. N=18, SEED=60.

## Запуск
Використано Python 3.14. Створіть чисте віртуальне середовище:

```
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m ipykernel install --user --name ml-lab4 --display-name "ML Lab 4"
```

Відкрийте ML-Practice-4.ipynb у Jupyter або VS Code, оберіть це ядро та виконайте Restart & Run All. Jupyter/VS Code є засобом відкриття Notebook і встановлюється окремо. Локальна копія даних у project/anneal_openml.joblib дозволяє працювати без мережі. Якщо копії немає, Notebook викликає fetch_openml(name='anneal', version=1, as_frame=True).

Не змінюйте SEED, бюджети й розбиття для порівняння з наданими результатами. Запуск повторно виконує 18 досліджень по 30 випробувань та перезаписує project/results/. Пошук може тривати кілька хвилин або довше. Відмінності версій і потокових реалізацій можуть впливати на точність відтворення; зафіксовані версії наведені в requirements.txt.

## Редагування й файли
project/lab_cells.txt - єдине редаговане джерело клітинок; project/build_notebook.py будує Notebook і коментоване Python-джерело project/lab.py. Команда з кореня архіву: `python project/build_notebook.py`. Вона створює Notebook без outputs; після неї виконайте його повністю.

project/results/model_*.joblib - збережені фінальні Pipeline (препроцесор + класифікатор); study_* - дослідження Optuna; splits.joblib - точні індекси поділів і LabelEncoder; baseline.joblib - усі базові оцінки блоків; table_1.csv ... table_7.csv - основні таблиці; решта CSV - аудит та інтерпретації; figure_*.png - справжні графіки обчислених результатів. checks.json зберігає програмні перевірки.

Інференс з кореня архіву:
```
import joblib
pipe = joblib.load('project/results/model_RF.joblib')
# frame - pandas DataFrame із початковими ознаками, що залишилися після аудиту
prediction = pipe.predict(frame)
encoder = joblib.load('project/results/splits.joblib')['encoder']
labels = encoder.inverse_transform(prediction.astype(int))
```
Завантажуйте joblib лише з довіреного комплекту. Усі збережені моделі навчені тільки на train; результат не охоплює виключений рідкісний клас 1.
