from pathlib import Path
import nbformat
root=Path(__file__).resolve().parent
text=(root/'lab_cells.txt').read_text().replace('—','-').replace('–','-')
nb=nbformat.v4.new_notebook()
py=[]
for block in text.split('# %%'):
 if not block.strip():continue
 markdown=block.startswith(' [markdown]')
 body=block.split('\n',1)[1] if markdown else block.lstrip('\n')
 nb.cells.append(nbformat.v4.new_markdown_cell(body) if markdown else nbformat.v4.new_code_cell(body))
 py.append('# %% [markdown]\n'+'\n'.join('# '+line for line in body.splitlines()) if markdown else '# %%\n'+body)
nb.metadata={'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.14'}}
nbformat.write(nb,root.parent/'ML-Practice-4.ipynb')
(root/'lab.py').write_text('\n\n'.join(py))
print('cells',len(nb.cells))
